##  README REFERENCE for Files Description conatined in the Reference-Files Directory

  - This Directory contains the Files Listed below for refernce to the commands used in this Homwork section

      * HTTP  Protocal and command syntax
      * cURL  Command line based utility for reference to command syntax and description
